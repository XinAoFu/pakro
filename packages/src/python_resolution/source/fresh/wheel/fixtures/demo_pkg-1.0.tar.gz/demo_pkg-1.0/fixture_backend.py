def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    raise RuntimeError("fixture continuation must not be executed by metadata routing")
